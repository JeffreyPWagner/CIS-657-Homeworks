import UIKit

//-----------Homework 1----------//

//Problem 1
let myString = "hello"
var cost = 3.14
let cnt: Int = 2
var shouldWe = true
let hexValue = 0x11
let decimalValue = Int(String(10, radix: 2))
print(decimalValue)

//Problem 2
let value: Double = 3.222

print("the final value is \(value)")


//Problem 3
var bees: [String] = ["queen","worker","drone"]
print(bees[0])
bees.append("honey")
bees+=["are","us"]
print(bees)

//Problem 4
for item in bees{
    print(item)
}
for (index,value) in bees.enumerated() {
    print("Item #\(index) is \(value)")
}

//Problem 5

var authorDict:[String:Decimal] = ["Mark Twain":8.9,"Nathaniel Hawthorne":5.1,"John Steinbeck":2.3,"C.S. Lewis":9.9,"Jon Krakaur":6.1]
var someDict1:[Int:String] = [1:"One", 2:"Two", 3:"Three"]

//Problem 6
print(authorDict["John Steinbeck"]!)
authorDict["Erik Larson"] = 9.2

if authorDict["Mark Twain"]! > authorDict["Jon Krakaur"]! {
    print("Mark Twain" )
}
else {
    print("Jon Krakaur" )
}

//Problem 7
for (author,score) in authorDict {
    print("\(author):\(score)")
}

//Problem 8
for index in 1...10 {
    print(index)
}

//Problem 9
for index in (1...10).reversed(){
    print(index)
}

//Problem 10
var x = 5
var y = 10
var product = 0
for _ in 1...y{
    product += x
}
print(product)

//---------Homework 2------------

//Problem 1
var i:Int = 0
var sum:Decimal = 0
let scores = Array(authorDict.values)

while i < authorDict.keys.count {
    sum += scores[i]
    i+=1
}
let average = sum/Decimal(i)
print("Average \(average)")

//Problem 2
if average < 5.0 {
    print("Low")
}
else if average < 7 {
    print("Moderate")
}
else {
    print("High")
}

//Problem 3
var strOut:String
var count = 1000
//---------------------------------VERIFY-------------------------//
switch count {
case 0:
    strOut = "none"
case 1...3:
    strOut = "a few"
case 4...9:
    strOut = "several"
case 10...99:
    strOut = "tens of"
case 100...999:
    strOut = "hundreds of"
case 1000...999999:
    strOut = "thousands of"
default:
    strOut = "millions of"
}

//Problem 4
func verbalizeNumber(count: Int) -> String {
    var returnString:String
    switch count {
    case 0:
        returnString = "none"
    case 1...3:
        returnString = "a few"
    case 4...9:
        returnString = "several"
    case 10...99:
        returnString = "tens of"
    case 100...999:
        returnString = "hundreds of"
    case 1000...999999:
        returnString = "thousands of"
    default:
        returnString = "millions of"
    }
    return returnString
}

//Problem 5
for index in (0...8).map({ pow(10,$0) }) {
    print(verbalizeNumber(count: Int(NSDecimalNumber(decimal: index)) ))
}

//Problem 6

